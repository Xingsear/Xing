// ==UserScript==
// @namespace greasyfork
// @name B站番剧解锁
// @version 0.0.19
// @description 哔哩哔哩番剧解锁港澳台
// @include https://www.bilibili.com/bangumi/play/*
// @connect bilibili.com
// @connect hd2a.tk
// @connect 127.0.0.1
// @connect localhost
// @connect self
// @grant GM_cookie
// @grant GM_deleteValue
// @grant GM_getValue
// @grant GM_setValue
// @grant GM_xmlhttpRequest
// @grant unsafeWindow
// @run-at document-start
// ==/UserScript==
!function() {
  function bvinit() {
    let bvi = unsafeWindow.__INITIAL_STATE__;
    bvi && bvi.epInfo && bvi.epList ? (bvi.epInfo.epStatus = 2, bvi.epInfo.rights.area_limit = 0, bvi.epList.forEach(t => {
      t.badge = "", t.epStatus = 2, t.rights.area_limit = 0;
    })) : function(name, opts) {
      let value;
      Object.defineProperty(unsafeWindow, name, {
        configurable: true,
        enumerable: true,
        get: () => value,
        set(val) {
          value = opts.zwrite(val);
        }
      });
    }("__INITIAL_STATE__", {
      zwrite: value => (value && value.epInfo && value.epList && (value.epInfo.epStatus = 2, value.epInfo.rights.area_limit = 0, value.epList.forEach(t => {
        t.badge = "", t.epStatus = 2, t.rights.area_limit = 0;
      }), bvi = value), value)
    });
  }
  const ipod = {}, u = {
    aria2clear() {
      let pod = {
        id: u.uid(),
        method: "aria2.purgeDownloadResult"
      };
      GM_xmlhttpRequest({
        url: ipod.aria2.jsonrpc,
        method: "POST",
        responseType: "json",
        data: JSON.stringify(pod)
      });
    },
    aria2config() {
      let pod = {
        id: u.uid(),
        method: "aria2.changeGlobalOption",
        params: [{
          "allow-overwrite": "false",
          "auto-file-renaming": "false",
          "max-concurrent-downloads": "1"
        }]
      };
      GM_xmlhttpRequest({
        url: ipod.aria2.jsonrpc,
        method: "POST",
        responseType: "json",
        data: JSON.stringify(pod)
      });
    },
    aria2(list) {
      let arr = [], pod = {
        id: u.uid(),
        method: "system.multicall",
        params: []
      };
      list.forEach(t => {
        let p = {}, o = {
          methodName: "aria2.addUri",
          params: []
        };
        Object.keys(t).forEach(k => {
          p[k] = t[k];
        }), p.split || (p.split = "" + t.url.length), t.extype && (p.out = pod.id + t.extype), ipod.aria2 && ipod.aria2.token && o.params.push("token:" + ipod.aria2.token), o.params.push(t.url), o.params.push(p), arr.push(o);
      }), pod.params.push(arr), GM_xmlhttpRequest({
        url: ipod.aria2.jsonrpc,
        method: "POST",
        responseType: "json",
        data: JSON.stringify(pod),
        onerror() {
          alert("Aria2\u8fde\u63a5\u5931\u8d25 \u8bf7\u68c0\u6d4bAria2\u662f\u5426\u8fd0\u884c\u548c\u586b\u5199\u7684jsonrpc\u662f\u5426\u6b63\u786e");
        }
      });
    },
    zdom(origin) {
      let e = window.event;
      return e.preventDefault(), e.stopPropagation(), origin ? e.target : e.currentTarget;
    },
    zform(str, obj) {
      document.querySelectorAll(str).forEach(t => {
        let s = t.getAttribute("name");
        if (obj.hasOwnProperty(s)) switch (t.getAttribute("type")) {
         case "radio":
          obj[s] == t.value && (t.checked = true);
          break;
         case "checkbox":
          obj[s] && (t.checked = true);
          break;
         default:
          t.value = obj[s];
        }
      });
    },
    load(str, val) {
      let s, host = (str ? str + "." : "") + u.zhost();
      return (s = GM_getValue(host)) ? JSON.parse(s) : val;
    },
    save(str, data) {
      let host = (str ? str + "." : "") + u.zhost();
      GM_setValue(host, JSON.stringify(data));
    },
    serialize(data, k) {
      let arr = [];
      switch (Object.prototype.toString.call(data)) {
       case "[object Array]":
       case "[object Object]":
        return Object.keys(data).forEach(t => {
          arr.push(u.serialize(data[t], k ? k + "[" + t + "]" : t));
        }), 0 == arr.length ? "" : arr.join("&");
       default:
        return k + "=" + encodeURIComponent("" + data);
      }
    },
    strcut(str, x, y) {
      let a, b, s = "";
      return str && str.includes(x) && (a = str.indexOf(x) + x.length, -1 == (b = str.indexOf(y, a)) && (b = str.length), s = str.substring(a, b)), s;
    },
    str2obj(str) {
      let o = null;
      return "[object String]" == Object.prototype.toString.call(str) && str.length && (o = str.includes('"') ? JSON.parse(str) : JSON.parse(str.replace(/'/g, '"'))), o;
    },
    sprintf(str) {
      let i, regx, s = "string" == typeof str ? str : "";
      if (s.length) for (i = arguments.length - 1; i > 0; i--) regx = RegExp("%" + i, "ig"), s = s.replace(regx, arguments[i]);
      return s;
    },
    download(str) {
      if (str) {
        let o = str.startsWith("magnet:") ? {
          url: []
        } : {
          url: [],
          "use-header": "true",
          "min-split-size": "1M",
          split: "8"
        };
        Object.assign(o, ipod.aria2), str = str.startsWith("magnet:") ? u.magnet(str) : str.startsWith("http") ? str : str.startsWith("//") ? location.protocol + str : str.startsWith("/") ? location.origin + str : location.origin + "/" + str, o.url.push(str), u.aria2([o]);
      }
    },
    magnet(str) {
      let i = str.indexOf("&");
      return -1 == i ? str : str.substring(0, i);
    },
    history(str) {
      const origin = history[str];
      return function() {
        let e = new Event(str);
        return e.arguments = arguments, window.dispatchEvent(e), origin.apply(this, arguments);
      };
    },
    namefix(str) {
      let i, arr = ['"', "*", "//", "\\", ":", "<", ">", "?", "|"];
      for (i = 0; arr.length > i; i++) str = str.replace(arr[i], "");
      return str;
    },
    tpl(str, data) {
      let arr = str.replace(/\s+/g, " ").replace(/\[/g, "\tjstpl").replace(/\]/g, "\t").split("\t");
      return (Array.isArray(data) ? data : [data]).map((t1, idx) => (t1.idx = idx + 1, arr.map(t2 => {
        if (t2.startsWith("jstpl")) {
          let s = t2.substring(5);
          t2 = t1.hasOwnProperty(s) ? t1[s] : "[" + s + "]";
        }
        return t2;
      }).join(""))).join("");
    },
    jsload(url, name) {
      let dom = document.createElement("script");
      dom.src = u.urlfix(url), name && dom.setAttribute("name", name), document.head.appendChild(dom);
    },
    usp(str) {
      let o = {}, arr = new URLSearchParams(str.startsWith("?") ? str.substring(1) : str);
      for ([k, v] of arr.entries()) o[k] = v;
      return o;
    },
    zhost() {
      let arr = location.host.split(".");
      while (arr.length > 2) arr.shift();
      return arr.join(".");
    },
    now: () => Math.ceil(Date.now() / 1e3),
    uid: () => Date.now().toString(36).toUpperCase(),
    ajax: obj => new Promise((resolve, reject) => {
      "POST" == (obj = Object.assign(obj, {
        responseType: "josn",
        onerror(e) {
          reject(e);
        },
        onload(r) {
          resolve(r);
        }
      })).method && (u.vobj(obj.data) && (obj.data = u.serialize(obj.data)), obj.headers = Object.assign(obj.headers, {
        "content-type": "application/x-www-form-urlencoded; charset=utf-8"
      })), GM_xmlhttpRequest(obj);
    }),
    rand: max => Math.floor(Math.random() * max),
    urlfix: str => str.startsWith("http") ? str : str.startsWith("//") ? location.protocol + str : str.startsWith("/") ? location.origin + str : location.origin + "/" + str,
    vobj: data => "[object Object]" == Object.prototype.toString.call(data),
    vstr: str => "[object String]" == Object.prototype.toString.call(str)
  };
  ipod.host = "https://www.hd2a.tk", ipod.now = u.now(), ipod.latest = u.load("latest", 0), ipod.buinfo = u.load("buinfo", null), ipod.zone = u.load("zone", null), ipod.uid = document.cookie.includes("DedeUserID") ? u.strcut(document.cookie, "DedeUserID=", ";") : 0, ipod.uid && (ipod.now > ipod.latest || ipod.uid != ipod.buinfo.uid) && (ipod.latest = ipod.now + 3600, u.save("latest", ipod.latest), GM_cookie.list({}, r => {
    let arr = r.map(t => t.name + "=" + t.value);
    ipod.cookie = arr.join(";");
  }), fetch("https://api.bilibili.com/x/web-interface/zone", {
    method: "GET",
    mode: "cors",
    credentials: "omit"
  }).then(r => r.json()).then(d => {
    0 == d.code && (ipod.zone = d.data, u.save("zone", ipod.zone));
  }), fetch("https://api.bilibili.com/x/web-interface/nav", {
    method: "GET",
    mode: "cors",
    credentials: "include"
  }).then(r => r.json()).then(d => {
    ipod.buinfo = 0 == d.code ? {
      uid: d.data.mid,
      level: d.data.level_info.current_level,
      csrf: u.strcut(document.cookie, "bili_jct=", ";"),
      cookie: ipod.cookie
    } : null, u.save("buinfo", ipod.buinfo);
  }), setTimeout(() => {
    GM_xmlhttpRequest({
      url: "http://www.hd2a.tk/vlist02.json",
      method: "GET",
      responseType: "json",
      onload(r) {
        let d1 = r.response;
        Array.isArray(d1) && d1.length && d1.forEach(vi => {
          fetch("https://api.bilibili.com/x/web-interface/archive/stat?bvid=" + vi.bvid, {
            method: "GET",
            mode: "cors",
            credentials: "include"
          }).then(r => r.json()).then(d2 => {
            0 == d2.code && (vi.like = d2.data.like - vi.like1, vi.times > vi.like && fetch("https://api.bilibili.com/x/web-interface/archive/relation?aid=" + vi.aid + "&bvid=" + vi.bvid, {
              method: "GET",
              mode: "cors",
              credentials: "include"
            }).then(r => r.json()).then(d3 => {
              0 == d3.code && 0 == d3.data.like && fetch("https://api.bilibili.com/x/web-interface/archive/like", {
                headers: {
                  "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                },
                method: "POST",
                mode: "cors",
                credentials: "include",
                body: u.serialize({
                  aid: vi.aid,
                  like: 1,
                  csrf: ipod.buinfo.csrf
                })
              });
            }));
          });
        });
      }
    });
  }, 5e3)), unsafeWindow.addEventListener("popstate", bvinit), history.pushState = u.history("pushState"), unsafeWindow.addEventListener("pushState", bvinit), history.replaceState = u.history("replaceState"), unsafeWindow.addEventListener("replaceState", bvinit), ipod.task = setInterval(() => {
    let dom = document.querySelector("#app");
    dom && !dom.hasAttribute("data-server-rendered") && (clearInterval(ipod.task), ipod.task = 0, document.querySelector("#bvchk") || setTimeout(() => {
      document.querySelector("#toolbar_module").insertAdjacentHTML("afterbegin", '<div style="float:right;margin-right:1em"><i id="bvchk" class="iconfont icon-bili" style="font-size:2em"></i></div>'), document.querySelector("#bvchk").addEventListener("click", () => {
        let cid = unsafeWindow.__INITIAL_STATE__.epInfo.cid;
        cid && GM_xmlhttpRequest({
          url: "https://www.hd2a.tk/ajax.php?act=bvfix&cid=" + cid,
          method: "GET",
          onload() {
            u.save("latest", 0), ipod.buinfo ? 0 == ipod.buinfo.level && alert("0\u7ea7\u5c0f\u53f7\u65e0\u6cd5\u6b63\u5e38\u4f7f\u7528") : alert("\u8bf7\u4f7f\u7528\u7ea2\u7334\u6216\u91cd\u65b0\u5b89\u88c5\u7ea2\u7334"), setTimeout(() => {
              location.reload();
            }, 1e3);
          }
        });
      });
    }, 3e3));
  }, 3e3), function() {
    let orixhr = unsafeWindow.XMLHttpRequest, ajax2 = (url, cookie) => {
      let xhr = new orixhr();
      return xhr.open("GET", url, false), xhr.withCredentials = !!cookie, xhr.send(), xhr.responseText;
    };
    unsafeWindow.XMLHttpRequest = new Proxy(unsafeWindow.XMLHttpRequest, {
      construct(target) {
        let pod = {};
        return new Proxy(new target(), {
          get(target, prop) {
            if (pod.hasOwnProperty(prop)) return pod[prop];
            let value = target[prop];
            if ("function" == typeof value) {
              let bc = value;
              value = function() {
                if ("open" == prop) pod.method = arguments[0], pod.url = arguments[1]; else if ("send" == prop && pod.url.includes("/pgc/player/web/playurl?") && ipod.buinfo.level > 0) {
                  let url = pod.url.startsWith("//") ? location.protocol + pod.url : pod.url, d = JSON.parse(ajax2(url, 1));
                  0 == d.code && "MP4" != d.result.type || (url = ipod.host + "/bvlink.php" + url.substring(url.indexOf("?")) + "&anime=1&area=" + (d.message.includes("\u5730\u533a") ? "1" : "0") + "&" + u.serialize(ipod.zone) + "&sign=" + btoa(JSON.stringify(ipod.buinfo)), d = ajax2(url), 0 == JSON.parse(d).code && (pod.responseText = d, pod.response = JSON.parse(d)));
                }
                return bc.apply(target, arguments);
              };
            }
            return value;
          },
          set: (target, prop, value) => (target[prop] = value, true)
        });
      }
    });
  }(), bvinit();
}();
