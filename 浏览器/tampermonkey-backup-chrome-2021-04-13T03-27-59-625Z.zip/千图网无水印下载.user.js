// ==UserScript==
// @name         千图网无水印下载
// @namespace    https://greasyfork.org/zh-CN/users/329780-zs6
// @version      0.3
// @description  下载无水印图
// @author       zs6
// @license      GPL-3.0-only
// @match        https://www.58pic.com/*
// @run-at document-end
// @noframes
// ==/UserScript==

(function() {
    'use strict';
    var src=document.querySelector(".pic-box").firstChild.getAttribute("data-src").replace(/preview/,"pic").split("jpg")[0];
    src='<a href=' +src+ 'jpg class="alert-color" data-mark-header="d_w_l" sta-site="4" stats-point="106" rel="nofollow" target="_blank">下载原图</a>'
    document.querySelector(".mainLeft-title").insertAdjacentHTML('beforeend',src);
})();