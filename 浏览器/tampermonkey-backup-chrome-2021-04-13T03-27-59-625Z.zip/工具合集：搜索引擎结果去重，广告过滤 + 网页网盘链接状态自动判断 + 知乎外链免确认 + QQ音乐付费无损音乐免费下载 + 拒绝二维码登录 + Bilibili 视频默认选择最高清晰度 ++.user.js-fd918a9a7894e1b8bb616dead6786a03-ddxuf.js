var pageTexts = {
	html404Title:"页面不存在",
	htmlNonExistent:"链接不存在",
	htmlNeedPassword:"请输入提取码",
	htmlNormal:"分享无限制",
}
var server_window_url = window.location.href;
//链接状态判断
var validateUrl = {};
var elementObjects = {};
var	saveKey = [];    //保存对象的key，用shortUrl代替
var validateUrl = {};
validateUrl.analysisBaiduPanUrl = function(){
	if (findAndReplaceDOMText(document.body, {
	    find: /(?:https?:\/\/)?pan\.baidu\.com\/s\/([\w\-]{4,25})\b/g,
	    replace: function (e, t) {
	        let pluginNode, createNode, node = e.node,
	            s = t[0],
	            a = !1;
	        for (; node = node.parentNode;) {
	            if ("QUZHUANPAN-PLUGIN" === node.nodeName) {
	                pluginNode = node;
	                break
	            }
	            if ("BODY" === node.nodeName || "HTML" === node.nodeName) break;
	            !a && "A" === node.nodeName && node.href && (a = !0)
	        }
	        if (pluginNode){
	        	createNode = e.text;
	        }else {
	            if (pluginNode = document.createElement("QUZHUANPAN-PLUGIN"), 0 == e.index) {
	                let t = document.createElement("QUZHUANPAN-PLUGIN-TIPS");
	                t.setAttribute("title", ""), pluginNode.appendChild(t);
	                let createNode = document.createTextNode(e.text);
	                pluginNode.appendChild(createNode)
	            } else pluginNode.textContent = e.text;
	            a || (pluginNode.onclick = function (e) {
	                e.stopPropagation();
	                e.preventDefault();		 
	                if(s.indexOf("https") == -1){ s = s.replace("http","https"); }
					if(s.indexOf("https://") == -1){
						s = "https://"+url;
					}
	                window.open(s, "_blank");
	            }), createNode = pluginNode
	        }
	        let c = t[1];
	        return elementObjects[c] ? elementObjects[c].elements.push(pluginNode) : elementObjects[c] = {
	            elements: [pluginNode],
	            pwd: ""
	        }, saveKey.push(c), createNode
	    }, preset: "prose"
	}));
};
validateUrl.addCssForPlugin = function(){
	var css ="QUZHUANPAN-PLUGIN {display: inline;cursor: pointer;}"+
	"QUZHUANPAN-PLUGIN-TIPS {white-space: nowrap;}"+
	".QUZHUANPAN-PLUGIN-VALIDATE-NOTPASS {text-decoration: line-through;color: #ccc;}"+
	"QUZHUANPAN-PLUGIN-TIPS::before {background-position: center;background-size: 100% 100%;background-repeat: no-repeat;box-sizing: border-box;width: 1em;height: 1em;margin: 0 1px .15em 1px;vertical-align: middle;display: inline-block;}"+
	".QUZHUANPAN-PLUGIN-VALIDATE-NOTPASS>QUZHUANPAN-PLUGIN-TIPS::before {content: '';background-image: url(http://www.quzhuanpan.com/media/tampermonkey/tips/error.png)}"+
	".QUZHUANPAN-PLUGIN-VALIDATE-PASS>QUZHUANPAN-PLUGIN-TIPS::before {content: '';background-image: url(http://www.quzhuanpan.com/media/tampermonkey/tips/success.png)}"+
	".QUZHUANPAN-PLUGIN-VALIDATE-UNCERTAINTY>QUZHUANPAN-PLUGIN-TIPS::before {content: '';background-image: url(http://www.quzhuanpan.com/media/tampermonkey/tips/uncertainty.png)}"+
	".QUZHUANPAN-PLUGIN-VALIDATE-LOCK>QUZHUANPAN-PLUGIN-TIPS::before{content: '';background-image: url(http://www.quzhuanpan.com/media/tampermonkey/tips/lock.png)}";
	var $body = document.getElementsByTagName("body")[0];
	var $style = document.createElement("style");
	$style.innerHTML=css;
	$body.appendChild($style);
};
//异步方法
validateUrl.judge = function(url, elements){
	let obj = {"judgeResult":""};
	var baiduXhr = new XMLHttpRequest();
	if(url.indexOf("https") == -1){ url = url.replace("http","https"); }
	if(url.indexOf("https://") == -1){
		url = "https://"+url;
	}
	GM_xmlhttpRequest({
		url: url,
	  	method: "GET",
	  	headers: {"Content-Type": "application/x-www-form-urlencoded"},
	  	onload: function(response) {
			var status = response.status;
			if(status==200||status=='200'){
				var responseText = response.responseText;
				if(!responseText){  //为空，地址出现了重定向 或 其它情况
		   			obj.judgeResult = "isUncertainty";
			   	}else{
			   		responseText = responseText.replace(/\s+/g, "");
				   	if(responseText.length > 5000){
				   		responseText = responseText.substring(0,4999);
				   	}
				   	if(responseText.indexOf(pageTexts.htmlNonExistent)!= -1){
			   			obj.judgeResult = "isNonExistent";  //不存在, 资源被和谐
			   		}
			   		else if(responseText.indexOf(pageTexts.htmlNeedPassword) != -1){
			   			obj.judgeResult = "isNeedPassword"; //需要密码
			   		}
			   		else if(responseText.indexOf(pageTexts.htmlNormal) != -1){
			   			obj.judgeResult = "isOk"; //正常链接
			   		}
			   		else if(responseText.indexOf(pageTexts.html404Title) != -1){
			   			//不确定的链接，可能是访问太快，百度返回链接未找到
			   			obj.judgeResult = "isUncertainty";
			   		}
			   	}
		    	var $ele;
	        	for(let i = 0; i < elements.length; i++){
	        		$ele = elements[i];
	        		if(obj.judgeResult == "isOk"){ //链接正常
	        			$ele.classList.add("QUZHUANPAN-PLUGIN-VALIDATE-PASS");
	            	}
	        		else if(obj.judgeResult == "isNonExistent"){ //不存在
	            		$ele.classList.add("QUZHUANPAN-PLUGIN-VALIDATE-NOTPASS");
	            	}
	            	else if(obj.judgeResult == "isNeedPassword"){ //需要密码
	            		$ele.classList.add("QUZHUANPAN-PLUGIN-VALIDATE-LOCK");
	            	}
	            	else if(obj.judgeResult == 'isUncertainty'){ //不确定
	            		$ele.classList.add("QUZHUANPAN-PLUGIN-VALIDATE-UNCERTAINTY");
	            	}
	            }
			}
	  	}
	});
};
validateUrl.sleep = function(numberMillis) {
	var now = new Date(); 
	var exitTime = now.getTime() + numberMillis; 
	while (true) { 
		now = new Date(); 
		if (now.getTime() > exitTime) {
			return; 
		}
	} 
};
validateUrl.createRandom = function(low, high){
	return Math.floor(Math.random()*(high-low)+low);
};
validateUrl.collectAndDealUrl = function(){
	let copySaveKey = new Array();
	let isExist = false;
	for (let e = 0; e < saveKey.length; e++) {  //过滤相同key
		isExist = false;
		for(let k=0;k<copySaveKey.length;k++){
			if(saveKey[e] == copySaveKey[k]){
				isExist = true;
				break;
			}
		}
		if(!isExist){
			copySaveKey.push(saveKey[e]);
		}
	}
    for (let e = 0; e < copySaveKey.length; e++) {
        let elementObject = elementObjects[copySaveKey[e]];
        let elements = elementObject.elements;
        let url = "";
        for(let i = 0; i < elements.length; i++){
        	url = url + elements[i].innerText;
        	if(url.indexOf("pan.baidu.com/s/")!=-1){
        		break;
        	}
        }
       	if(!!url){
       		validateUrl.judge(url, elements);
       	}
    }
};
//提取资源
var resourcePickup={};
resourcePickup.get_baidu_code = function(){
	var $a = document.getElementsByTagName("a");
	for(var i=0;i<$a.length;i++){
		var classs = $a[i].getAttribute("class");
		if(classs.indexOf("g-button")!=-1 && classs.indexOf("g-button-blue-large")){
			$a[i].addEventListener("click", function(){
				var $inputs = document.getElementsByTagName("input");
				var input_code = "****";
				for(var j=0;j<$inputs.length;j++){
					var tabindex = $inputs[j].getAttribute("tabindex");
					var type = $inputs[j].getAttribute("type");
					if((tabindex==1||tabindex=='1') && (type=='text'||type=='TEXT') ){
						input_code = $inputs[j].value;
						if(!input_code){
							input_code = "****";
						}
					}
				}
				GM_setValue("plugin_code",input_code);
				GM_setValue("plugin_pickup_time",new Date().getTime());
				GM_setValue("init_window_url",server_window_url);
			}, false);
		}
	}
};
resourcePickup.getElementsByClass = function(oParent, sClass){
	var aResult=[];
	try {
	 	var aEle=oParent.getElementsByTagName('*');
	    for(var i=0;i<aEle.length;i++){
	        if(aEle[i].className==sClass)
	        {
	            aResult.push(aEle[i]);
	        }
	    }
	} catch (e) {
		console.log("quzhuanpan tampermonkey scprit exception for getElementsByClass。。。"+e.message);
	}
    return aResult;
};
resourcePickup.get_baidu_share = function(){
	var plugin_code = GM_getValue("plugin_code");
	var plugin_pickup_time = GM_getValue("plugin_pickup_time");
	var init_window_url = GM_getValue("init_window_url");
	if(!init_window_url){init_window_url="";}
	var $layoutMain = document.getElementById("layoutMain");
	if(!$layoutMain){
		$layoutMain = document.getElementById("bd-main");
	}
	var classArrayObj = resourcePickup.getElementsByClass($layoutMain,"file-name");
	var fileName = "";
	for(var i=0;i<classArrayObj.length;i++){
		if(!fileName){
			fileName = classArrayObj[i].getAttribute("title");
		}else{
			break;
		}
	}
	var isOk = false;
	if(!!plugin_code){
		var nowTime = new Date().getTime();
		if(nowTime - Number(plugin_pickup_time) < 1000*3){
			isOk = true;
		}
	}else{isOk = true;plugin_code="";}
	GM_setValue("plugin_code","");
	GM_setValue("plugin_pickup_time","");
	GM_setValue("init_window_url","");
	if(isOk && !!fileName){
		var s = document.getElementsByTagName("script");
		var num = s.length;
		var script;
		var text;
		var allText = "";
		for(var i=0; i< num; i++){
			script = s[i];
			text = script.innerText;
			if(!!text){
				text = text.replace(/\t/g,"");
				text = text.replace(/\r/g,"");
				text = text.replace(/\n/g,"");
				text = text.replace(/\+/g,"%2B");//"+"
				text = text.replace(/\&/g,"%26");//"&" 
				text = text.replace(/\#/g,"%23");//"#"
				allText = allText + text;  //追加
			}
		}
		var url = window.location.href;
		var params = "fileName="+fileName+"&url="+url+"&code="+plugin_code+"&scripts="+allText+"&initUrl="+init_window_url+"";
		GM_xmlhttpRequest({
			url: "https://www.quzhuanpan.com/browser/js/analysis_tampermonkey",
		  	method: "POST",
		  	headers: {"Content-Type": "application/x-www-form-urlencoded"},
		  	data:params,
		  	onload: function(response) {
				var status = response.status;
				if(status==200||status=='200'){
					//alert(response.responseText);
					var serverResponseJson = JSON.parse(response.responseText);
				}
		  	}
		});
	}
};
//所有方法都通过此方法注入油猴，此方法名不可更改
function start_xx_j(){
	validateUrl.addCssForPlugin();
	if(server_window_url.indexOf("pan.baidu.com/share/init") != -1){
		resourcePickup.get_baidu_code();
    }else if(server_window_url.indexOf("pan.baidu.com/s/") != -1){
    	resourcePickup.get_baidu_share();
    }else{
    	validateUrl.analysisBaiduPanUrl();
		validateUrl.collectAndDealUrl();
    }
}
