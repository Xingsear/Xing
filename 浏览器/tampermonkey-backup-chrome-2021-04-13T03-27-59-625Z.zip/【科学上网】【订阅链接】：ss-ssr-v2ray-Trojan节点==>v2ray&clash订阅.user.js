// ==UserScript==
// @name         【科学上网】【订阅链接】：ss/ssr/v2ray/Trojan节点==>v2ray&clash订阅
// @name:en      【科学上网】【订阅链接】：ss/ssr/v2ray/Trojan节点==>v2ray&clash订阅
// @name:zh-TW   【科学上网】【订阅链接】：ss/ssr/v2ray/Trojan节点==>v2ray&clash订阅
// @name:zh-HK   【科学上网】【订阅链接】：ss/ssr/v2ray/Trojan节点==>v2ray&clash订阅
// @namespace    http://tampermonkey.net/
// @version      3.0
// @description  分享v2ray&clash订阅链接，包含ss/ssr/v2ray/Trojan节点。使用方法：1.打开百度首页，退出登录，右键复制相应链接导入相应客户端，更新订阅。2.打开bing.com，后面步骤同方法1
// @description:en  We share v2ray&clash subscription link here, including ss/ssr/v2ray/Trojan node. Usage: 1. Open the Baidu homepage, log out, right click to copy the corresponding link to import the corresponding client, and update the subscription. 2. Open bing.com, the following steps are the same as method 1
// @description:zh-TW 分享v2ray&clash订阅链接，包含ss/ssr/v2ray/Trojan节点。使用方法：1.打开百度首页，退出登录，右键复制相应链接导入相应客户端，更新订阅。2.打开bing.com，后面步骤同方法1
// @description:zh-HK 分享v2ray&clash订阅链接，包含ss/ssr/v2ray/Trojan节点。使用方法：1.打开百度首页，退出登录，右键复制相应链接导入相应客户端，更新订阅。2.打开bing.com，后面步骤同方法1
// @author       hello world
// @require      https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js
// @match        https://www.baidu.com/
// @match        *.bing.com/
// @include      https://www.baidu.com/
// @include      *.bing.com/
// ==/UserScript==
ImportCss();
ScriptWithJquery();

function ImportCss() {
    var jqueryScriptBlock = document.createElement('style');
    jqueryScriptBlock.type = 'text/css';
    jqueryScriptBlock.innerHTML = "#see{position:fixed;bottom:10%;right:10px;border:2px solid red;padding:20px;width:400px;font-size:13px;cursor:pointer;border-radius: 3px;}";
    document.getElementsByTagName('head')[0].appendChild(jqueryScriptBlock);
}
function ScriptWithJquery() {
     $(document.body).append("<div id='see'> <b>📌【说明】：</b><br><br>不定期重置，重置后该链接失效，获取新的订阅链接即可<br><br><b>右键复制订阅地址:</b>  <a href='https://api.wcc.best/sub?target=v2ray&url=https%3A%2F%2Fdlj.tf%2Fi9o0Znl&insert=false&config=https%3A%2F%2Fraw.githubusercontent.com%2FACL4SSR%2FACL4SSR%2Fmaster%2FClash%2Fconfig%2FACL4SSR_Online.ini' target='_blank'>【V2ray】</a>   <a href='https://acl4ssr-sub.github.io/' target='_blank'>【♻️订阅转换网址♻️】</a><br><br>  <a href='https://raw.githubusercontent.com/coolapijust/cxkv2-/main/README.md' target='_blank'><b>【新增V2ray订阅1】</b></a>        <a href='https://raw.githubusercontent.com/coolapijust/cxkv2-/main/plate' target='_blank'><b>【新增V2ray订阅2】</b></a>   <br><br><a href='https://api.wcc.best/sub?target=clash&new_name=true&url=https%3A%2F%2Fhm2019721.ml%2Fclash%2Fproxies%3Fc%3DHK%26filter%3D1%26type%3Dvmess%2Ctorjan&insert=false&config=https%3A%2F%2Fraw.githubusercontent.com%2FACL4SSR%2FACL4SSR%2Fmaster%2FClash%2Fconfig%2FACL4SSR_Online.ini' target='_blank'>【<b>♻️新增订阅3</b>{只适用clash、小火箭、圈X(带解析器)}♻️】</a><br><br><a href='https://github.com/2dust/v2rayN/releases/download/4.6/v2rayN-Core.zip' target='_blank'>【V2ray下载】</a>   <a href='https://github.com/Fndroid/clash_for_windows_pkg/releases/download/0.14.1/Clash.for.Windows-0.14.1-win.7z' target='_blank'>【Clash下载】</a>   <a href='https://telegra.ph/%E5%90%84%E7%A7%8D%E6%95%99%E7%A8%8B%E6%B3%A8%E6%84%8F%E4%BA%8B%E9%A1%B9-01-27' target='_blank'>【🟢🔴教程(fq)+节点分享🔴🟢】</a><br><br><b>⚠️免责声明⚠️</b><br>只面向海外华人用户且仅供科研学习之用，切勿用于其他用途<br>中国居民请自觉关闭并在24小时之内删掉与本项目相关的一切内容<br>否则出现一切问题，项目作者概不负责</div>");

}