// ==UserScript==
// @name         百度文库资料免费下载助手
// @namespace    devret
// @version      1.0.0
// @description  百度文库资料免费下载！
// @author       devret@qq.com
// @include      *://wenku.baidu.com/view/*
// @require      http://cdn.bootcss.com/jquery/1.12.4/jquery.min.js
// @require      https://cdn.bootcss.com/sweetalert/2.1.2/sweetalert.min.js
// @require      http://code.jquery.com/jquery-latest.js
// ==/UserScript==

(function() {
    'use strict';

    addBtn();
    addDownloadBtnEvent(getDownloadURL());

    function addBtn(){
                var download = "<div id='wenkudownload'   style='cursor:pointer;z-index:98;display:block;width:30px;height:30px;line-height:30px;position:fixed;left:0;top:300px;text-align:center;overflow:visible'><p style='font-size:25px;color:red'>免费下载</p></div>";
                $("body").append(download);
    }

    function getDownloadURL(){
        var url = window.location.href;
        url =  url.replace(/baidu.com/g,"baiduvvv.com");
        return url;
    }

   function addDownloadBtnEvent(url){
       $("#wenkudownload").click(function(){
       window.open(url);
       });
   }
})();